This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-friday/

Super Friday is a versatile font that can be used for a variety of purposes. With its unique style, it’s sure to add a touch of personality to your projects.

